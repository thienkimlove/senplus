<div class="sortInfoBlock">
    <div class="fixCen">
        <div class="avatar">
            <img src="{{ \App\Helpers::getLoginCompanyLogo() }}" alt="" class="imgFull">
        </div>
        <div class="txt">
            {{ \App\Helpers::getLoginCompany()->name }}
        </div>
    </div>
</div>